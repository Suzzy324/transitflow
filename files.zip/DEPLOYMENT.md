# TransitFlow — Smart Transport Subscription System
## Deployment Instructions

---

## 📁 Project Structure
```
smart-transport-system/
└── index.html          ← Entire application (single file)
```

---

## 🚀 Option 1: GitHub Pages (FREE — Recommended for FYP)

### Steps:
1. Go to **github.com** → Create a new repository (e.g. `transitflow`)
2. Upload `index.html` to the root of the repo
3. Go to **Settings → Pages**
4. Under "Source", select **main branch → / (root)**
5. Click **Save**
6. Your app is live at: `https://yourusername.github.io/transitflow/`

**⏱ Takes ~2 minutes to deploy**

---

## 🌐 Option 2: Netlify (FREE — Instant Deploy)

### Steps:
1. Go to **netlify.com** → Sign up free
2. Drag and drop the `index.html` file onto the Netlify dashboard
3. Done! You get a URL like `https://random-name.netlify.app`
4. Optionally rename it in Site Settings

**⏱ Takes ~30 seconds**

---

## ⚡ Option 3: Vercel (FREE)

1. Go to **vercel.com** → Sign up with GitHub
2. Create a folder, put `index.html` inside, name it `index.html`
3. Run in terminal:
```bash
npm i -g vercel
vercel --yes
```
Or drag-and-drop via the Vercel web UI.

---

## 💻 Option 4: Run Locally (No internet needed)

Simply double-click `index.html` — it opens in any browser. No server needed!

Or use VS Code Live Server:
```bash
# Install VS Code extension: "Live Server"
# Right-click index.html → Open with Live Server
```

---

## 🔐 Demo Credentials

| Role  | Email                     | Password  |
|-------|---------------------------|-----------|
| Admin | admin@transitflow.com     | admin123  |
| User  | Register your own account | any pass  |

---

## ✅ Features Implemented

| Feature                        | Status |
|-------------------------------|--------|
| User Registration & Login      | ✅     |
| Admin Dashboard                | ✅     |
| 3 Subscription Plans           | ✅     |
| Trip Booking with Fare Calc    | ✅     |
| Real-time Fare Estimation      | ✅     |
| Trip Pass Top-ups              | ✅     |
| User Dashboard & Analytics     | ✅     |
| Fleet Management View          | ✅     |
| Revenue Breakdown (Admin)      | ✅     |
| Data Persistence (localStorage)| ✅     |
| Responsive Mobile Design       | ✅     |
| Subscription Cancel/Upgrade    | ✅     |

---

## 📊 System Architecture (for your report)

```
Frontend (HTML/CSS/JS)
    ├── Authentication Module
    │       ├── Login / Register
    │       └── Session persistence
    ├── Subscription Engine
    │       ├── Plan selection & billing
    │       └── Usage tracking
    ├── Booking Engine
    │       ├── Fare matrix calculator
    │       ├── Zone-based pricing
    │       └── Booking history
    ├── User Dashboard
    │       ├── Trip analytics
    │       └── Subscription status
    └── Admin Panel
            ├── User management
            ├── Fleet status
            └── Revenue reporting

Data Layer: Browser localStorage (JSON)
```

---

## 📝 FYP Presentation Notes

- **Technology**: Vanilla HTML5, CSS3, JavaScript (no dependencies)
- **Data Storage**: localStorage for persistence (no backend required)
- **Transport Modes**: Bus, Metro, Express Bus, BRT
- **Pricing Model**: Zone-based fare matrix with subscription discounts
- **Security**: Role-based access (admin vs user)

---

*Good luck with your submission! 🎓*
